package tour;

import search.DepthFirstFrontier;
import search.Frontier;
import search.GoalTest;
import search.Node;
import search.Search;
import search.TreeSearch;

public class DFTS_Demo {
	public static void main(String[] args) {
		System.out
				.println("This is a demonstration of depth-first tree search on Romania tour");
		System.out.println();

		System.out.println();

		Cities romaina = SetUpRomania.getRomaniaMapSmall();
		City startCity = romaina.getState("Bucharest");

		Frontier frontier = new DepthFirstFrontier();
		GoalTest goalTest = new TourGoalTest(romaina.getAllCities(), startCity);
		Search search = new TreeSearch(frontier);
		Node solution = search.findSolution(new TourState(startCity), goalTest);
		new TourPrinting().printSolution(solution);
		System.out.println("Number of generated nodes:               "
				+ search.getNumberOfNodesInLastSearch());
		System.out.println("Maximum number of nodes on the frontier: "
				+ frontier.getMaximumNumberOfNodesOnFrontier());
	}
}
