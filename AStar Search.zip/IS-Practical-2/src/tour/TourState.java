package tour;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

import search.Action;
import search.State;

public class TourState implements State {
	protected final Set<City> visitedCities;
	protected final City currentCity;
	
	public TourState(City startCity) {
		this.visitedCities = Collections.emptySet();
		this.currentCity = startCity;
	}
	public TourState(Set<City> visitedCities, City currentCity) {
		this.visitedCities = visitedCities;
		this.currentCity = currentCity;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Set<Action> getApplicableActions() {
		// This is a minor hack in order to circumvent Java's annoying type system.
		// This could have been solved in a nicer way using generics; however, this
		// has not been done in order not to complicate matters any further.
		return (Set<Action>)(Set)currentCity.outgoingRoads;
	}
	public State getActionResult(Action action) {
		Road road = (Road)action;
		Set<City> newVisitedCities = new LinkedHashSet<City>(visitedCities);
		newVisitedCities.add(road.targetCity);
		return new TourState(newVisitedCities, road.targetCity);
	}
	public boolean equals(Object that) {
		if (this == that)
			return true;
		if (!(that instanceof TourState))
			return false;
		TourState thatTourState = (TourState)that;
		return visitedCities.equals(thatTourState.visitedCities) && currentCity.equals(thatTourState.currentCity);
	}
	public int hashCode() {
		return visitedCities.hashCode() * 7 + currentCity.hashCode();
	}
}
