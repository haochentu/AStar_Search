package tour;

import search.BreadthFirstFrontier;
import search.Frontier;
import search.GoalTest;
import search.Node;
import search.Search;
import search.TreeSearch;

public class BFTS_Demo {
	public static void main(String[] args) {
		System.out
				.println("This is a demonstration of breadth-first tree search on Romania tour");
		System.out.println();

		System.out.println();

		Cities romaina = SetUpRomania.getRomaniaMapSmall();
		// Cities romaina = SetUpRomania.getRomaniaMap();
		City startCity = romaina.getState("Bucharest");

		Frontier frontier = new BreadthFirstFrontier();
		GoalTest goalTest = new TourGoalTest(romaina.getAllCities(), startCity);
		Search search = new TreeSearch(frontier);
		Node solution = search.findSolution(new TourState(startCity), goalTest);
		new TourPrinting().printSolution(solution);
		System.out.println("Number of generated nodes:               "
				+ search.getNumberOfNodesInLastSearch());
		System.out.println("Maximum number of nodes on the frontier: "
				+ frontier.getMaximumNumberOfNodesOnFrontier());
	}
}
