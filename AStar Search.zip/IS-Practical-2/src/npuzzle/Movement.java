package npuzzle;

import search.Action;
import search.Node;

public enum Movement implements Action {
	UP(-1, 0, 1), LEFT(0, -1, 1), DOWN(1, 0, 1), RIGHT(0, 1, 1);
	//add the cost as the 3rd parameter
	
	public final int deltaRow;
	public final int deltaColumn;
	
	private Movement(int deltaRow, int deltaColumn, int cost) {
		this.deltaRow = deltaRow;
		this.deltaColumn = deltaColumn;
		cost = cost();  
	}
	
	public int cost() {
		return 1;
	}
}
