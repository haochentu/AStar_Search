package npuzzle;

import search.GoalTest;
import search.Node;
import search.NodeFunction;
import search.State;

public class MisplacedTilesHeuristicFunction implements NodeFunction {

	private Tiles tiles;

	@Override
	public int hValue(Node n) {
		int misplacedTiles = 0; 
		Tiles state = null;
		tiles = (Tiles)state;
		int lastTileIndex = tiles.width * tiles.width - 1;
		for (int index = lastTileIndex - 1; index >=0; --index)
			if (tiles.tiles[index] != index + 1) {
				misplacedTiles ++; 
			}
		return misplacedTiles;
	}
}


/**   private ArrayList<State> getChildren(State currState, int searchFunction) {
        ArrayList<State> retArray = new ArrayList<>();
        int[][] currGrid = currState.getGrid();
        int g_n = currState.getG_n();
        int zero_loc_x = -1;
        int zero_loc_y = -1;
        for(int i=0; i<PUZZLE_SIZE; i++) {
            for(int j=0; j<PUZZLE_SIZE; j++) {
                if(currGrid[i][j]==0) {
                    zero_loc_x = i;
                    zero_loc_y = j;
                }
            }
        }
        
       case A_STAR_MISPLACED_TILE:
    for(int i=0; i<PUZZLE_SIZE; i++)
        for(int j=0; j<PUZZLE_SIZE; j++) {
            if(currGrid[i][j] != goalState[i][j])
                h_n ++;
        }
    break;
 * @return */