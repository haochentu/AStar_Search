package npuzzle;

import search.AStarFunction;
import search.BestFirstFrontier;
import search.Frontier;
import search.GoalTest;
import search.GraphSearch;
import search.Node;
import search.NodeFunction;
import search.Search;

public class ASGS_Demo {
	public static void main(String[] args) {
		System.out.println("This is a demonstration of A* graph search on 8-puzzle");
		System.out.println();
		
		Tiles initialConfiguration = new Tiles(new int[][] {
			{ 7, 4, 2 },
			{ 8, 1, 3 },
			{ 5, 0, 6 }
		});
		
		NodeFunction MisplacedTilesHeuristicFunction = new AStarFunction();
		Frontier frontier = new BestFirstFrontier(MisplacedTilesHeuristicFunction);
		GoalTest goalTest = new TilesGoalTest();
		Search search = new GraphSearch(frontier);
		Node solution = search.findSolution(initialConfiguration, goalTest);
		new NPuzzlePrinting().printSolution(solution);
		System.out.println("Number of generated nodes:               " + search.getNumberOfNodesInLastSearch());
		System.out.println("Maximum number of nodes on the frontier: " + frontier.getMaximumNumberOfNodesOnFrontier());
	}
}
