package search;

public interface NodeFunction { 
	int hValue(Node node); 
	//cost to the current node + h
}
