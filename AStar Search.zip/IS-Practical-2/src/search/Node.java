package search;

public class Node {
	public final int depth;
	public static int costToNode;
	public final Node parent;
	public final Action action;
	public final State state;
	public int value;
	
	
	public Node(Node parent, Action action, State state) {
		this.depth = (parent == null ? 0 : parent.depth + 1);
		//if parent == null then this.depth = 0; else equals....   
		Node.costToNode = (parent == null? 0 : parent.costToNode + 1); 
		///cost to reach the node + cost from parent to this node 
		this.parent = parent;
		this.action = action;
		this.state = state;
	}


	public static int costToNode(Node node) {
		// TODO Auto-generated method stub
		return costToNode;
	}
}
