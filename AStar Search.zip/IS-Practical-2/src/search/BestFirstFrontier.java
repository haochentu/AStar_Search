package search;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;


public class BestFirstFrontier implements Frontier {
	
	protected final NodeFunction nodeFunction;
	protected int maximumNumberOfNodesOnFrontier;
	
	protected PriorityQueue<Node> queue = new PriorityQueue<Node>(
			new Comparator<Node>() {
				public int compare(Node i, Node j) {
					if ((hvalue(i) > hvalue(j))) {
	                    return 1;
	                }

	                else if (hvalue(i) < hvalue(j)) {
	                    return -1;
	                }

	                else {
	                    return 0;
	                }
				}
			});

	public BestFirstFrontier(NodeFunction nodeFunction) {
		queue = new PriorityQueue<Node>();
		this.nodeFunction = nodeFunction; 
		maximumNumberOfNodesOnFrontier = 0;
	}
	
	
	//when a node is added to a best-first frontier
	//the frontier should invoke the evaluation function on the node to determine the node's value
	//and it should store the value in the node	
	public void addNode(Node node) {
		node.value = hvalue(node); 
		queue.add(node); 
		if (queue.size() > maximumNumberOfNodesOnFrontier)
			maximumNumberOfNodesOnFrontier = queue.size();
	}


	private int hvalue(Node node) {
		// TODO Auto-generated method stub
		return hvalue(node);
	}


	public void clear() {
		// TODO Auto-generated method stub
		queue.clear();
	}


	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return queue.isEmpty();
	}


	@Override
	//when removing a node from a best-first frontier,
	//a node with the lowest value should be returned;
	//if there are several such nodes, the one of them should be selected arbitrarily 
	public Node removeNode() {
		return queue.remove();
	}


	@Override
	public int getMaximumNumberOfNodesOnFrontier() {
		// TODO Auto-generated method stub
		return maximumNumberOfNodesOnFrontier;
	}
	
	//override NodeFundtion
	//h(n) = estimated cost of the cheapest path from the state at node n to a goal state
	//goal state: h(n) = 0 

}
