package search;

public class BreadthFirstFrontier extends AbstractQueueFrontier {
	public Node removeNode() {
		return queue.removeFirst();
	}
}
