package search;

public interface GoalTest {
	boolean isGoal(State state);
}
