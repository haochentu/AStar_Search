package search;

import java.util.LinkedList;

public abstract class AbstractQueueFrontier implements Frontier {
	protected final LinkedList<Node> queue;
	protected int maximumNumberOfNodesOnFrontier;

	public AbstractQueueFrontier() {
		queue = new LinkedList<Node>();
		maximumNumberOfNodesOnFrontier = 0;
	}
	
	public void clear() {
		queue.clear();
	}
	public boolean isEmpty() {
		return queue.isEmpty();
	}
	public void addNode(Node node) {
		queue.add(node);
		if (queue.size() > maximumNumberOfNodesOnFrontier)
			maximumNumberOfNodesOnFrontier = queue.size();
	}
	public int getMaximumNumberOfNodesOnFrontier() {
		return maximumNumberOfNodesOnFrontier;
	}
}
