package search;

import java.util.PriorityQueue;

public class AStarFunction implements NodeFunction{
	
	private Node node;
	private NodeFunction heuristicFunction;
	
	public int AStarFunction(NodeFunction heuristicFunction) {
		this.heuristicFunction = heuristicFunction;
		return Node.costToNode(node) + heuristicFunction(node); 
	}
	
	private int heuristicFunction(Node node) {
		return hValue(node);
	}

	@Override
	public int hValue(Node node) {
		return hValue(node);
	}

}
