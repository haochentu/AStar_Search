package search;

public class DepthFirstFrontier extends AbstractQueueFrontier {
	public Node removeNode() {
		return queue.removeLast();
	}
}
