package search;

import java.util.Set;

public class TreeSearch implements Search {
	protected final Frontier frontier;
	protected int numberOfNodes;

	public TreeSearch(Frontier frontier) {
		this.frontier = frontier;
	}

	public Node findSolution(State initialState, GoalTest goalTest) {
		numberOfNodes = 0;
		frontier.clear();
		frontier.addNode(new Node(null, null, initialState));
		while (!frontier.isEmpty()) {
			Node node = frontier.removeNode();
			// System.out.println(node.depth + " - " + node.
			// if (node.depth > 40)
			// return null;
			if (goalTest.isGoal(node.state))
				return node;
			else {
				Set<Action> applicableActions = node.state
						.getApplicableActions();
				for (Action action : applicableActions) {
					State newState = node.state.getActionResult(action);
					frontier.addNode(new Node(node, action, newState));
					numberOfNodes++;
				}
			}
		}
		System.gc();
		return null;
	}

	public int getNumberOfNodesInLastSearch() {
		return numberOfNodes;
	}
}
