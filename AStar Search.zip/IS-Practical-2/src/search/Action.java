package search;

public interface Action {
	int cost();  
}
