package search;

import java.util.Set;

public class IterativeDeepeningTreeSearch implements Search {
	protected final static Node CUTOFF = new Node(null, null, null);
	
	protected final Frontier frontier;
	protected int numberOfNodes;
	
	public IterativeDeepeningTreeSearch() {
		this.frontier = new DepthFirstFrontier();
	}
	public Node findSolution(State initialState, GoalTest goalTest) {
		numberOfNodes = 0;
		int depthLimit = 0;
		Node result = CUTOFF;
		while (result == CUTOFF) {
			result = findSolution(initialState, goalTest, depthLimit);
			depthLimit++;
		}
		return result;
	}
	protected Node findSolution(State initialState, GoalTest goalTest, int depthLimit) {
		frontier.clear();
		frontier.addNode(new Node(null, null, initialState));
		boolean cutoffOccurred = false;
		while (!frontier.isEmpty()) {
			Node node = frontier.removeNode();
			if (goalTest.isGoal(node.state))
				return node;
			else if (node.depth >= depthLimit)
				cutoffOccurred = true;
			else {
				Set<Action> applicableActions = node.state.getApplicableActions();
				for (Action action : applicableActions) {
					State newState = node.state.getActionResult(action);
					frontier.addNode(new Node(node, action, newState));
					numberOfNodes++;
				}
			}
		}
		return cutoffOccurred ? CUTOFF : null;
	}
	public int getNumberOfNodesInLastSearch() {
		return numberOfNodes;
	}
	public Frontier getFrontier() {
		return frontier;
	}
}
