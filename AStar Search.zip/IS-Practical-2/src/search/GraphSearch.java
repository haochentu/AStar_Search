package search;

import java.util.LinkedHashSet;
import java.util.Set;

public class GraphSearch implements Search {
	protected final Frontier frontier;
	protected int numberOfNodes;

	public GraphSearch(Frontier frontier) {
		this.frontier = frontier;
	}

	public Node findSolution(State initialState, GoalTest goalTest) {
		numberOfNodes = 0;
		frontier.clear();
		frontier.addNode(new Node(null, null, initialState));
		Set<State> visitedStates = new LinkedHashSet<State>();
		while (!frontier.isEmpty()) {
			Node node = frontier.removeNode();
			System.out.println(node.depth + " - " + node.parent);
			if (goalTest.isGoal(node.state))
				return node;
			else {
				Set<Action> applicableActions = node.state
						.getApplicableActions();
				for (Action action : applicableActions) {
					State newState = node.state.getActionResult(action);
					if (visitedStates.add(newState)) {
						frontier.addNode(new Node(node, action, newState));
						numberOfNodes++;
					}
				}
			}
		}
		return null;
	}

	public int getNumberOfNodesInLastSearch() {
		return numberOfNodes;
	}
}
